import{l}from"../chunks/_page.5206eea5.js";export{l as load};
