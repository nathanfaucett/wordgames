import{l}from"../chunks/_page.7a3e9c64.js";export{l as load};
