import{default as t}from"../entry/error.svelte.bd830b0c.js";export{t as component};
