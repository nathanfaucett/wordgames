import{default as t}from"../entry/_page.svelte.44a8d552.js";export{t as component};
