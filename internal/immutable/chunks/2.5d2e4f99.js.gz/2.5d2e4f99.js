import{default as t}from"../entry/_page.svelte.6497a7cb.js";export{t as component};
