import{default as t}from"../components/pages/game/_page.svelte-c32e3ff0.js";export{t as component};
