import{default as t}from"../entry/error.svelte.04911d46.js";export{t as component};
