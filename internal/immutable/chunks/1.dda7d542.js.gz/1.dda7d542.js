import{default as t}from"../entry/error.svelte.dfa32e1d.js";export{t as component};
