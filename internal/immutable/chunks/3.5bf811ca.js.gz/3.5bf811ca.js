import{_ as r}from"./_page.5206eea5.js";import{default as t}from"../entry/game-page.svelte.3a08ffe0.js";export{t as component,r as universal};
