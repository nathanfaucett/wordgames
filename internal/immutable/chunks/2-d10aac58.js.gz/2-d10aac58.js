import{default as t}from"../components/pages/_page.svelte-6f8e5d75.js";export{t as component};
