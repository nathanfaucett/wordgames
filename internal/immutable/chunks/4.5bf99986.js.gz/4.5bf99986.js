import{_ as r}from"./_page.5206eea5.js";import{default as t}from"../entry/lobby-page.svelte.769be575.js";export{t as component,r as universal};
