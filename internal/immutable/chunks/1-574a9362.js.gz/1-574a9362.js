import{default as t}from"../components/error.svelte-060ce551.js";export{t as component};
