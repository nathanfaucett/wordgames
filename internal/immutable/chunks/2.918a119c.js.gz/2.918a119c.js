import{default as t}from"../entry/_page.svelte.32cd272f.js";export{t as component};
