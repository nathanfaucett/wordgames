import{_ as r}from"./_page.7a3e9c64.js";import{default as t}from"../entry/game-page.svelte.7dcfe50d.js";export{t as component,r as universal};
