import{default as t}from"../entry/_page.svelte.aa242727.js";export{t as component};
