import{default as t}from"../entry/error.svelte.1f0853cf.js";export{t as component};
