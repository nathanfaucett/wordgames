import{default as t}from"../components/pages/lobby/_page.svelte-ab853c2b.js";export{t as component};
